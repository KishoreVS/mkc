package com.pwd.service;

import java.util.List;

import com.pwd.entities.Employee;

public interface EmployeeService {
   public abstract void load(Employee employee);
   //public abstract Employee findByEmployeeName(String employeeName);
   //public abstract Employee fetchEmployeeById(int employeeId);
  // public abstract void deleteEmployeeById(int employeeId);
   //public abstract void updateEmployeeEmailById(String newEmail , int employeeId);
   public abstract List<Employee> findAll();
}
