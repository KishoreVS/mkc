package com.pwd.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.bind.annotation.GetMapping;

import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;

import com.pwd.dao.UserJpaRespository;
import com.pwd.entities.Employee;

@Service("employeeService")
public class EmployeeServiceImpl implements EmployeeService{
	
	 @Autowired
	    private UserJpaRespository userJpaRespository;

	    @GetMapping(value = "/all")
	    public List<Employee> findAll() {
	        return userJpaRespository.findAll();
	    }

	    
	  //  @GetMapping(value = "/{name}")
	    //public Employee findByName(@PathVariable final String name){
	    //    return userJpaRespository.findByName(name);
	   // }

	    /**
		 * Used to create a User in the DB
		 * 
		 * @param users refers to the User needs to be saved
		 * @return the {@link User} created
		 */
	    @PostMapping(value = "/load")
	    public void load(@RequestBody final Employee employee) {
	        userJpaRespository.save(employee);
	      //  return userJpaRespository.findByName(employee.getEmployeeName());
	    }


	


		


		
	}
	//http://localhost:9494/users/load


