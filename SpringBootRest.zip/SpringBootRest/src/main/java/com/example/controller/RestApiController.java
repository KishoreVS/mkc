package com.example.controller;




import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.example.entities.Module;
import com.example.service.ServiceImpl;



@RestController
@RequestMapping("/module")
public class RestApiController {

	@Autowired
	private ServiceImpl ser;

	
	@GetMapping(value = "/{id}")
	public Optional<Module> findById(@PathVariable final int id) {
		return ser.getByUserId(id);
	}
	
	@GetMapping(value = "/name/{name}")
	public Module findByName(@PathVariable final String name) {
		return ser.getByUserName(name);
	}
	
	 @PostMapping(value = "/add")
	 public Module addUserData(@RequestBody final Module mod) {
		 return ser.addData(mod);
	  }
	 
	 @PutMapping(value = "/update")
	 public Boolean updateUserData(@RequestBody final Module mod) {
//		 Optional<Module> m = ser.getByUserId(id);
//		 m.get().setName(mod.getName());
		 if(mod == null) {
			 
			 throw new UserNotFoundException("user not found for id");
		 }
		 return ser.updateData(mod);
	 }
	 
	 @ExceptionHandler(UserNotFoundException.class) 
	     public ResponseEntity userNotFound(UserNotFoundException e) { 
	         return new ResponseEntity(e.getMessage(), HttpStatus.NOT_FOUND); 
	     } 

	 
	 @DeleteMapping(value = "/delete/{id}")
	 public Boolean deleteUserData(@PathVariable final int id) {
		 return ser.deleteData(id);
	 }
	
//	@RequestMapping(value = "/employee/find/{id}",
//			method = RequestMethod.GET,
//			produces = "application/json")
//	public ResponseEntity<Employee> findEmployee(@PathVariable("id") int id){
//		
//		Employee emp = ser.findUserById(id);
//		if(emp == null) {
//			throw new UserNotFoundException("user not found");
//		}
//		ResponseEntity<Employee> responseEntity = new ResponseEntity<Employee>(emp, HttpStatus.OK);
//	    System.out.println("response entity=" + responseEntity);
//	    return responseEntity;
//		
//	}
//	
//	  @ExceptionHandler(UserNotFoundException.class)
//	    public ResponseEntity userNotFound(UserNotFoundException e) {
//	        return new ResponseEntity(e.getMessage(), HttpStatus.NOT_FOUND);
//	    }
//	  
//	  @RequestMapping(value = "/employee/create",
//	            method = RequestMethod.POST,
//	            consumes = {"application/json"},
//	            produces = "application/json")
//	    public ResponseEntity<Boolean> createUser(@RequestBody Employee emp) {
//		  	int id = emp.getId();
//		  	String name = emp.getName();
//	        Boolean r = ser.createUser(id, name);
//	        ResponseEntity<Boolean> responseEntity = new ResponseEntity(true, HttpStatus.OK);
//	        System.out.println("response entity=" + responseEntity);
//	        return responseEntity;
//	    }
//	  
//	  @RequestMapping(value = "/employee/update/{id}",
//	            method = RequestMethod.PUT,
//	            consumes = {"application/json"},
//	            produces = "application/json")
//	    public ResponseEntity<Boolean> updateUser(@RequestBody Employee emp,@PathVariable("id") int id) {
//		 
//		  	String name = emp.getName();
//	        Employee em = ser.updateNameById(id, name);
//	        ResponseEntity<Boolean> responseEntity = new ResponseEntity(true, HttpStatus.OK);
//	        System.out.println("response entity=" + responseEntity);
//	        return responseEntity;
//	    }
//	  
//	  @RequestMapping(value = "/employee/delete/{id}",
//	            method = RequestMethod.DELETE,
//	            produces = "application/json")
//	    public ResponseEntity<Boolean> deleteUser(@PathVariable("id") int id) {
//		 
//		  	
//	        Boolean em = ser.deleteById(id);
//	        ResponseEntity<Boolean> responseEntity = new ResponseEntity(true, HttpStatus.OK);
//	        System.out.println("response entity=" + responseEntity);
//	        return responseEntity;
//	    }
	
}
