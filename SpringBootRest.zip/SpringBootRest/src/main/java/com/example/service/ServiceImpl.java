package com.example.service;



import java.lang.annotation.Annotation;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.controller.UserNotFoundException;
import com.example.entities.Module;
import com.example.repository.DaoImpl;



@Service
public class ServiceImpl implements ServiceI {

	@Autowired
	DaoImpl ds;

	@Override
	public Optional<Module> getByUserId(int id) {
		// TODO Auto-generated method stub
		if(!ds.existsById(id))
		{
			throw new UserNotFoundException("user with id "+id +"does not exist.");
		}
		return ds.findById(id);
	}

	@Override
	public Module addData(Module module) {
		// TODO Auto-generated method stub
		return ds.save(module);
	}

	@Override
	public Boolean updateData(Module module) {
		// TODO Auto-generated method stub
//		Optional<Module> mod = ds.findById(module.getId());
//		
//		mod.get().setId(module.getId());
//		mod.get().setName(module.getName());
//		mod.get().setFees(module.getFees());
//		mod.get().setDuration(module.getDuration());
		
		ds.save(module);
		
		return true;
	}

	@Override
	public Boolean deleteData(int id) {
		// TODO Auto-generated method stub
		
		
		ds.deleteById(id);
		
		return true;
	}

	@Override
	public Module getByUserName(String name) {
		// TODO Auto-generated method stub
		return ds.findByName(name);
	}




	

	
}
