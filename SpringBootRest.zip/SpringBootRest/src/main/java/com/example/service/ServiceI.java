package com.example.service;

import java.util.Optional;

import com.example.entities.Module;

public interface ServiceI {

	
	Optional<Module> getByUserId(int id);
	
	Module getByUserName(String name);
	
	Module addData(Module module);
	
	Boolean updateData(Module module);
	
	Boolean deleteData(int id);
	
//	Optional<Module> findUserById(int id);
//
//    Module createUser(Module user);
//
//    Boolean createUser(int id,String name);
//    
//    Module updateNameById(int id,String name);
//    
//    Boolean deleteById(int id);
	
}
