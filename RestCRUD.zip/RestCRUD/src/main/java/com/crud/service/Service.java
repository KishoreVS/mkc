package com.crud.service;

import com.crud.entities.Employee;

public interface Service {

	
	Employee findUserById(int id);

    Employee createUser(Employee user);

    Employee createUser(int id,String name);
    
    Employee updateNameById(int id,String name);
	
}
