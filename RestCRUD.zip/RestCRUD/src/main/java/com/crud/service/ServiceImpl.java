package com.crud.service;



import java.lang.annotation.Annotation;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.crud.dao.Dao;
import com.crud.entities.Employee;

@Service
public class ServiceImpl implements Service{

	@Autowired
	Dao ds;
	
	public Employee findUserById(int id) {
		// TODO Auto-generated method stub
		return ds.findUserById(id);
	}

	public Employee createUser(Employee user) {
		// TODO Auto-generated method stub
		return null;
	}

	public Employee createUser(int id, String name) {
		// TODO Auto-generated method stub
		return ds.createUser(id, name);
	}

	public Employee updateNameById(int id,String name) {
		// TODO Auto-generated method stub
		return ds.updateNameById(id,name);
	}

	public Class<? extends Annotation> annotationType() {
		// TODO Auto-generated method stub
		return null;
	}

	public String value() {
		// TODO Auto-generated method stub
		return null;
	}

	

	
}
