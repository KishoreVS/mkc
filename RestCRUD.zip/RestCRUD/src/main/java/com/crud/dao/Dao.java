package com.crud.dao;

import com.crud.entities.Employee;

public interface Dao {

	Employee findUserById(int id);

    Employee createUser(Employee user);

    Employee createUser(int id,String name);
    
    Employee updateNameById(int id,String name);
	
}
