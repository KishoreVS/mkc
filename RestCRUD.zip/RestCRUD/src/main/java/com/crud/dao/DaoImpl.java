package com.crud.dao;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;

import org.springframework.stereotype.Repository;

import com.crud.entities.Employee;

@Repository
public class DaoImpl implements Dao {

	@PersistenceContext
	private EntityManager em;
	
	public Employee findUserById(int id) {
		// TODO Auto-generated method stub
		Employee e = em.find(Employee.class, id);
		return e;
	}

	public Employee createUser(Employee user) {
		// TODO Auto-generated method stub
		return null;
	}

	public Employee createUser(int id, String name) {
		// TODO Auto-generated method stub
		Employee e1 = new Employee();
		e1.setId(id);
		e1.setName(name);
		
		
		
		return em.merge(e1);
	}

	public Employee updateNameById(int id,String name) {
		// TODO Auto-generated method stub
		Employee e = em.find(Employee.class, id);
		e.setName(name);
		return em.merge(e);
	}

	
	
	
}
