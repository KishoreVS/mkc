package com.crud.controller;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.crud.dao.UserNotFoundException;
import com.crud.entities.Employee;
import com.crud.service.Service;

@RestController
public class RestApiController {

	@Autowired
	private Service ser;

	
	@RequestMapping(value = "/employee/find/{id}",
			method = RequestMethod.GET,
			produces = "applicatoin/json")
	public ResponseEntity<Employee> findEmployee(@PathVariable("id") int id){
		
		Employee emp = ser.findUserById(id);
		if(emp == null) {
			throw new UserNotFoundException("user not found");
		}
		ResponseEntity<Employee> responseEntity = new ResponseEntity<Employee>(emp, HttpStatus.OK);
	    System.out.println("response entity=" + responseEntity);
	    return responseEntity;
		
	}
	
	  @ExceptionHandler(UserNotFoundException.class)
	    public ResponseEntity userNotFound(UserNotFoundException e) {
	        return new ResponseEntity(e.getMessage(), HttpStatus.NOT_FOUND);
	    }
	  
	  @RequestMapping(value = "/user/create",
	            method = RequestMethod.POST,
	            consumes = {"application/json"},
	            produces = "application/json")
	    public ResponseEntity<Boolean> createUser(@RequestBody Employee emp) {
		  	int id = emp.getId();
		  	String name = emp.getName();
	        emp = ser.createUser(id, name);
	        ResponseEntity<Boolean> responseEntity = new ResponseEntity(true, HttpStatus.OK);
	        System.out.println("response entity=" + responseEntity);
	        return responseEntity;
	    }
	  
	
}
