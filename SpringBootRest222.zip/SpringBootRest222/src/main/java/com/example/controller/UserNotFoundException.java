package com.example.controller;

public class UserNotFoundException extends RuntimeException{
	private String timestamp;
	private String message;
	private String details;
    public UserNotFoundException(String msg){
        super(msg);
    }
    
    public UserNotFoundException() {}

//    public UserNotFoundException(String msg,Throwable e){
//        super(msg,e);
//    }

	
    
}
