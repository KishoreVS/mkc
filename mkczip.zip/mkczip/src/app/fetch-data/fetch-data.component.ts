import { Component, OnInit } from '@angular/core';
import { DataServiceService } from '../data-service.service';
import { DB } from '../model/db';

@Component({
  selector: 'app-fetch-data',
  templateUrl: './fetch-data.component.html',
  styleUrls: ['./fetch-data.component.css']
})
export class FetchDataComponent implements OnInit {

  service: DataServiceService
  emp: DB[];
  constructor(service: DataServiceService) {
    this.service = service
  }

  ngOnInit() {
    this.emp = this.service.addData()
    console.log(this.emp)
  }

}
