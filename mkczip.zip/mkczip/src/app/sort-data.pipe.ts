import { Pipe, PipeTransform } from '@angular/core';

@Pipe({
  name: 'sortData'
})
export class SortDataPipe implements PipeTransform {

  transform(array:any[],col:string,column:boolean){
    if(col==undefined){
        return array;
    }
    if(column){
          array=array.sort((i:any,j:any)=>{
              //sorting conditon for ascending order.
              // if(i[col]>j[col]){
              //     return 1;
              // }
              if(col === 'name' || col === 'category'){
                if (j[col] < i[col]) 
                return -1;
                else if (j[col] > i[col]) return 1;
                else return 0;
              }
              else{
                return j[col] - i[col]
              }
             // return -1;
          });
          return array;
        }
        else{
          array=array.sort((i:any,j:any)=>{
            //sorting conditon for descending order.
            // if(i[col]>j[col]){
            //     return -1;
            // }
            if(col === 'name' || col === 'category'){
              if (i[col] < j[col]) 
              return -1;
              else if (i[col] > j[col]) return 1;
              else return 0;
            }
            else{
               return i[col] - j[col]
            }
            //return 1;
        });
        return array;
        }
  }

}
