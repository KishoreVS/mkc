import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http'
import { DB } from './model/db';
@Injectable({
  providedIn: 'root'
})
export class DataServiceService {

  http: HttpClient
  arrDB: DB[] = [];
  constructor(http: HttpClient) {
    this.http = http;
    this.fetchingData()
  }

  isFetched: boolean = false;
  fetchingData() {
    this.http.get('../assets/db.json')
      .subscribe((data) => {
        if (!this.isFetched) {
          this.isFetched = true;
          this.convert(data);
        }
      })
  }

  convert(data: any) {
    for (let e of data) {
      let d = new DB(e.ProductId,e.Category,e.MainCategory,e.TaxTarifCode,e.SupplierName);
      this.arrDB.push(d);
     
    }
  }

  

  addData() {
    return this.arrDB;
  }

  
}
